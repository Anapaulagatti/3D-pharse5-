KOREAN ARENA — Hangeul Pixel Town, Gate2 ART RESET v2 — NOT APPROVED
Unzip, open a terminal in this directory, run python3 start.py (Windows: py start.py). Open the HTTP address printed. Do not open HTML in a source-text viewer or move the 3D-pharse5- directory. Python3 required; Node/npm not needed for viewing. Stop server with Ctrl+C.
WASD/arrows walk; Shift run; E near Mira; Space wave. Buttons/touch pad also available. A/B/C style selector and1x/2x/3x zoom; OS reduced motion respected. No real online players, learning quest, ads, cloud services or paid content.
Original editable source is in repository branch rebuild/pixel-social-rpg-v3. This static package excludes old3D sources/releases. Public website remains v0.5 until separately approved replacement.
