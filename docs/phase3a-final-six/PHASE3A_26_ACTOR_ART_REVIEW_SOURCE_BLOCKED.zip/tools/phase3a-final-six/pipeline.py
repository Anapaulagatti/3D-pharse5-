"""Reuse the frozen illustrated NPC tooling through isolated source/output roots.

No old actor or tool is rewritten. Primary art is host imagegen, not code drawing.
Costumes remain explicitly speculative until independent sources are available.
"""
from pathlib import Path
import importlib.util,json,sys,hashlib,shutil
R=Path(__file__).resolve().parents[2]
S=R/'assets-src/npcs/phase3a-final-six';D=R/'docs/phase3a-final-six'
IDS=['history-seondeok','history-sejong','history-jang','history-saimdang','history-yi','history-yu']
CONFIG={
 'history-seondeok':{'hip':80,'knee':87,'shoe':95,'shoulder':49,'hem':95,'robe':True},
 'history-sejong':{'hip':80,'knee':87,'shoe':94,'shoulder':49,'hem':93,'robe':True},
 'history-jang':{'hip':80,'knee':88,'shoe':94,'shoulder':49,'hem':82,'robe':True,'narrowLegs':False,'ankleAtShinEdge':True,'accessories':{'front':[[51,59,61,78]],'back':[[35,59,44,78]],'left':[[36,59,45,78]],'right':[]}},
 'history-saimdang':{'hip':80,'knee':87,'shoe':95,'shoulder':49,'hem':94,'robe':True},
 'history-yi':{'hip':78,'knee':87,'shoe':93,'shoulder':49,'hem':80,'robe':True,'narrowLegs':False,'ankleAtShinEdge':True},
 'history-yu':{'hip':80,'knee':87,'shoe':94,'shoulder':49,'hem':93,'robe':True,'ankleAtShinEdge':True},
}
def module(name):
 p=R/f'tools/phase3a-npc-expansion/{name}.py'
 spec=importlib.util.spec_from_file_location('history_reuse_'+name,p)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 m.S=S;m.D=D
 return m
def finish(id):
 from PIL import Image
 p=S/id
 n=module('native');n.SPLIT[id]=Image.open(p/'turnaround-source.png').height//2;n.finish(id)
def rig(id):
 m=module('rig');m.CONFIG[id]=CONFIG[id];m.author(id)
 # Long robes leave a short visible ankle; shoe RGB belongs exclusively to
 # its native translated layer, never to a rotated shin a second time.
 from PIL import Image
 import numpy as np
 for path in (S/id/'layers').glob('*/*shin.png'):
  a=np.array(Image.open(path).convert('RGBA'));a[CONFIG[id]['shoe']:]=0
  Image.fromarray(a).save(path)
 if CONFIG[id].get('robe'):
  for view in ['front','back','left','right']:
   folder=S/id/'layers'/view;cfgv=json.loads((S/id/'rig.json').read_text())['views'][view]
   shoe_mask=np.zeros((112,96),dtype=bool)
   for side in ['L','R']:
    path=folder/(side+'shoe.png');a=np.array(Image.open(path).convert('RGBA'))
    if view in ['front','back']:
     if side=='L':a[:,46:]=0
     else:a[:,:51]=0
    Image.fromarray(a).save(path);shoe_mask|=a[:,:,3]>0
    for segment in ['thigh','shin']:
     path=folder/(side+segment+'.png');a=np.array(Image.open(path).convert('RGBA'));cx=cfgv['joints'][side][0][0]
     if CONFIG[id].get('narrowLegs',True):a[:,:cx-4]=0;a[:,cx+5:]=0
     Image.fromarray(a).save(path)
   path=folder/'body.png';a=np.array(Image.open(path).convert('RGBA'))
   if view in ['left','right']:
    own=np.array(Image.open(S/id/'native'/f'{view}.png').convert('RGBA'));a[76:CONFIG[id]['hem']+1]=own[76:CONFIG[id]['hem']+1]
   a[shoe_mask]=0;Image.fromarray(a).save(path)
 cfg=json.loads((S/id/'rig.json').read_text());cfg['robeOwnership']='Whole illustrated robe remains body-owned; narrow under-robe legs, exclusive native shoes, no skirt pixels rotated as wide legs'
 if CONFIG[id].get('ankleAtShinEdge'):
  for view,c in cfg['views'].items():
   for side in ['L','R']:
    bb=Image.open(S/id/'layers'/view/(side+'shoe.png')).getbbox()
    c['joints'][side][2]=[(bb[0]+bb[2]-1)/2,CONFIG[id]['shoe']-1]
 cfg['shoeOwnership']='Shin mask excludes shoe rows, avoiding duplicate rotated shoe pixels under long robes'
 for view,c in cfg['views'].items():
  for name,owner in c['ownership'].items():
   im=Image.open(S/id/'layers'/view/(name+'.png'));a=np.array(im)
   owner.update(pixels=int((a[:,:,3]>0).sum()),bounds=im.getbbox())
 cfg['nativeMaskAudit']='Actual post-registration alpha counts and bounds recorded for every retained own layer'
 (S/id/'rig.json').write_text(json.dumps(cfg,indent=2)+'\n')
def animate(id):
 m=module('animate')
 if CONFIG[id].get('ankleAtShinEdge'):
  import inspect
  # Register the cuff to the TOP of this actor's own native shoe, not a
  # hardcoded3px sole offset (Jang's shoes are6px tall).
  for fn in ['forward','profile']:
   code=inspect.getsource(getattr(m,fn)).replace('sole[1]-3',"sole[1]-(parts[side+'shoe'].getbbox()[3]-parts[side+'shoe'].getbbox()[1]-1)")
   exec(code,m.__dict__)
 m.build(id,False)
def audit(id):return module('audit').actor(id)
def export(id):
 p=S/id;report=audit(id)
 if report['errors']:raise RuntimeError(report['errors'])
 out=R/f'public/assets/npcs/phase3a/npc-{id}'
 for a,b in [('candidate-atlas.png','atlas.png'),('candidate-preview-native.png','preview-native.png')]:shutil.copyfile(p/a,out/b)
 files=[p/n for n in ['master-source.png','turnaround-source.png','rig.json','native-finish.json']]
 record={'id':'npc-'+id,'art_source':'host_image','tool':'image_gen.imagegen','sources':{str(q.relative_to(R)):hashlib.sha256(q.read_bytes()).hexdigest() for q in files},'nativeCell':[96,112],'footAnchor':[48,100],'nativeCells':104,'sourceOwnedLayers':44,'costumeStatus':'SPECULATIVE ERA-QUALIFIED PROPOSAL; institutional verification blocked','historicalContentVerified':False,'humanArtApproval':'PENDING','qa':report['status']}
 (out/'provenance.json').write_text(json.dumps(record,indent=2)+'\n')
def pack_metadata(id):
 out=R/f'public/assets/npcs/phase3a/npc-{id}';out.mkdir(exist_ok=True)
 m=json.loads((R/'public/assets/npcs/phase3a/npc-seoyeon/atlas.json').read_text());m['meta']['image']='atlas.png'
 (out/'atlas.json').write_text(json.dumps(m,indent=2)+'\n')
if __name__=='__main__':
 action=sys.argv[1]
 for id in sys.argv[2:]:
  assert id in IDS
  if action=='all':
   pack_metadata(id);finish(id);rig(id);animate(id);export(id)
  else:globals()[action](id)
