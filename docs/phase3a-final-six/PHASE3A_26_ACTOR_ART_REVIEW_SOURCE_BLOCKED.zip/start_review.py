from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from argparse import ArgumentParser
import os
p=ArgumentParser();p.add_argument('--port',type=int,default=4416);p.add_argument('--lan',action='store_true');a=p.parse_args();os.chdir(Path(__file__).resolve().parent)
print(f'Open http://127.0.0.1:{a.port}/REVIEW.html',flush=True)
print('20productionNPCs /26ARTcandidateIDs. Historicalfacts/costumesUNVERIFIED;physicaldevicesNOTTESTED;Phase3BLOCKED.',flush=True)
ThreadingHTTPServer(('0.0.0.0'if a.lan else'127.0.0.1',a.port),SimpleHTTPRequestHandler).serve_forever()
