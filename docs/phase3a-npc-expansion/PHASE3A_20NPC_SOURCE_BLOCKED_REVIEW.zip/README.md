# Korean Arena · actual20NPC / requested26 · source-blocked review

Run python3 start_review.py and open the printed local REVIEW.html. No Node/install/network needed to PLAY. Default bind is127.0.0.1;--lan is an explicit private-LAN test option,not a deployment.

Complete frozen canonical world,12approved players,28cosmetics/46variants,14residents with illustrated art and6original cultural visitors. Three approved pilots remain unchanged. Six historical encounters and source-verified real-person index are NOT completed because official sources return proxy403;no placeholder history sprites or unverified biographies are shipped. Final human art approval pending. Physical Android/iPhone/hardwareGPU NOT TESTED. Phase3B LOCKED,no main merge or public deployment.

The source-code checkpoint,full hashes/logs/native evidence and limitations are in docs/phase3a-npc-expansion. This ZIP includes native sources/layers/rigs,actual1:1context crops,17short direct gameplay excerpts and a live native5column Phaser inspector. Full-resolution illustration sources,complete raw-size world PNGs and full videos are versioned in the immutable review ref and linked online;those optional authoring/evidence links are not required to play. The inspector is supplemental atlas playback,not navigation proof. Re-authoring requires the full repository and documented optional tooling/dependencies.
