# Private two-bridge review

Run `python3 start_review.py`, open the localhost URL. Original WASD/arrows, Shift run, mobile joystick, E explore, Scenic/Tour/Return and report export preserved. Native art remains1:1. Physical devices/hardware performance NOT TESTED. Human bridge art approval pending. No public site deployed.
