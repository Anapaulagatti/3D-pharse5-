# Korean Arena — Phase2B roster expansion

Read docs/current/PROJECT_STATE.md. Human approval explicitly accepts Phase2A at ed75734d0e0865274ca0b82bab2495d78878d24b and supersedes its STOP. Work on feature/phase2b-roster-expansion. No delegation unless explicitly requested by user.

- Six approved identities, atlases, animation packs, native96×112/48,100 registration and60/100 speeds are immutable. Freeze docs/phase2b/approved-six.json. Ten cosmetics, four suggested looks, local preset/schema and original source/tools remain unchanged.
- World/collision/controls/camera/tour frozen: verify docs/phase1/protected-world.json and protected-juni.json. No map edits, collision patches or separate learning-site changes.
- Extend existing Registry and Studio; no second character or animation engine. Promote planned slots only after native art/locomotion validation. Three controlled pairs: Sori/Jiwon, Nari/Taeyang, Yuna/Hyunwoo; actual Phaser movement checks and checkpoint after each pair. Follow the accepted Phase2A own-layer native authoring workflow with host image masters; no paid external API.
- Preserve lazy/bounded caches, one active sprite, v1/v2 appearance persistence and position/visited state. New six default outfits only; incompatible cosmetics remain hidden.
- Six Phase2A and eleven historical numerical motion warnings remain documented. Do not weaken validators or call browser emulation physical-device PASS.
- Deliver all twelve, native/playable/video/QA/provenance review package, then STOP for human artistic approval. No Phase2C, NPC/quests/shops/farming/learning/ads/multiplayer, main merge or public deployment.

Phase2B is now a complete twelve-character review candidate. Preserve checkpoint/phase2b-twelve-characters-review-20261026, source art/layers and intermediate wave refs. See docs/phase2b/README.md, QA.md and PROTECTED_AUDIT.md. Six new identities await human artistic approval. STOP; do not begin Phase2C, merge or deploy without explicit new authorization.

## Active human direction2026-10-27 — critical motion correction

Six new Phase2B character DESIGNS are accepted as the basis; their front/back/right locomotion is REJECTED. This supersedes the prior review STOP only for a focused six-character motion repair. Preserve checkpoint/phase2b-motion-before-20261027 and docs/phase2b-motion/before-manifest.json. Do not redesign identities, change any of the approved six, edit UI/runtime/controls/camera/world/collision or begin Phase2C. Author only affected own motion frames and derived guides; audit related runs, preserve left and all non-motion cells. Juni's actual phases are the benchmark. Require genuine positive-X forward stance, three consecutive actual gameplay loops and synchronized comparisons, not just eight hashes. Original Forge thresholds/WARN history remain unchanged. Deliver the corrected candidate and STOP for human motion review.

## Active recovery direction2026-10-27

Recover existing d988e12; do not repeat animation production. Finish validation, full review ZIP and safe publication on feature/phase2b-roster-expansion, preserving approved references. User explicitly authorizes publishing this review branch/checkpoints, not main merge or public deployment. Stop for human motion review after delivery; Phase2C stays LOCKED.
