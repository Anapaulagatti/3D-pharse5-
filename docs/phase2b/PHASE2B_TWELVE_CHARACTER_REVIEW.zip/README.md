# Korean Arena Phase2B Character Studio

Run python3 start_review.py and open REVIEW.html. This is the actual compiled Phaser game with the frozen canonical world, twelve playable characters and native-frame cosmetics. The game runs locally/offline; full authoring sources and large native evidence are linked to the immutable source checkpoint.

Six original identities are human-approved and unchanged. Six new identities are review candidates with native/technical validation, awaiting human Phase2B approval. Physical Android/iPhone and hardware performance NOT TESTED. No Phase2C, main merge or public deployment.
