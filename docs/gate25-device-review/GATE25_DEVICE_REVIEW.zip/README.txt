GATE 2.5 HUMAN-APPROVED VISUAL PROTOTYPE / PHYSICAL DEVICE REVIEW ONLY
Gate3 LOCKED. Android Chrome NOT TESTED; iPhone Safari NOT TESTED.
Extract, run python3 start.py --lan on a computer; use its LAN IP on phones on the same trusted Wi-Fi. Stop with Ctrl-C. No public deployment.
Open http://COMPUTER_LAN_IP:8065/3D-pharse5-/gate2-review.html?scene=district-refinement
Frozen game files and picker labels are unchanged; approval is recorded in APPROVAL.md and CHECKPOINT.json.
Read DEVICE_CHECKLIST.md, fill DEVICE_REPORT_ANDROID.json / DEVICE_REPORT_IPHONE.json.
Options(...) > Export test report downloads JSON. Record real device model/OS/browser; attach exported files and actual screenshots/screen recordings. No physical PASS without evidence.
This handoff does not authorize fixes, Gate3, full-world production, main merge, deployment or large expansion. Stop and wait for explicit authorization.
