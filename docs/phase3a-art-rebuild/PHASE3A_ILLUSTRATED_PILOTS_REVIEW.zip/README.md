# Korean Arena:3illustrated NPC pilots

Run python3 start_review.py;open http://127.0.0.1:4388/REVIEW.html. Actual frozen canonical Phaser world with Seoyeon/Minseo/Harin illustrated replacements,12original players,28cosmetics and unchanged NPC engine. No Node,install or network needed to play. --lan explicitly opts into your own LAN only.

Only3pilots under HUMAN ART REVIEW. Elevenother NPCs retain REJECTED old art and must not be interpreted as approved;their IDs/routes/engine remain preserved awaiting this gate. Do not begin their rebuild or Phase3B.

Three actual AFTER world videos,native comparisons and the supplementary Phaser clip inspector are included. Original3masters/turnarounds,native sources,rig masks/frames and tooling are bundled for inspection. Reproduction audits need the full Git repository and documented optional authoring dependencies. BEFORE videos and large native scene PNGs link online at the immutable review tag. The clip inspector is an atlas QA utility,NOT canonical gameplay or collision proof.

Normal tests PASS;third-party gait heuristic FAIL/WARN retained including same tests on approved Juni. One Harin6pixel existing tree-ground occlusion documented. Physical devices/hardware NOT TESTED. Human ART APPROVAL PENDING. No merge/publicdeployment.
