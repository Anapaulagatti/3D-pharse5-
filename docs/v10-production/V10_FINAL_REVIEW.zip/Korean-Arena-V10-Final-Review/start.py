"""V10 final-art review — local HTTP launcher (Python 3, no Node required)."""
import argparse,functools,http.server,pathlib,webbrowser
p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8080);p.add_argument('--no-browser',action='store_true');a=p.parse_args()
class Handler(http.server.SimpleHTTPRequestHandler):
 def end_headers(self):
  self.send_header('Cache-Control','no-store');super().end_headers()
directory=pathlib.Path(__file__).resolve().parent/'site'
with http.server.ThreadingHTTPServer(('127.0.0.1',a.port),functools.partial(Handler,directory=str(directory))) as server:
 url=f'http://127.0.0.1:{server.server_port}/3D-pharse5-/v10-city-review.html'
 print('V10 FINAL ART — awaiting visual approval',flush=True);print(url,flush=True)
 if not a.no_browser:webbrowser.open(url)
 try:server.serve_forever()
 except KeyboardInterrupt:pass
