V10 PLAYABLE FINAL ART — awaiting final visual approval.
Extract, enter this folder, run python3 start.py (Windows: py start.py).
WASD/arrows walk, Shift runs, E interacts; touch joystick on landscape mobile.
Original V10 southern artwork; final visual approval pending. No public deployment.
