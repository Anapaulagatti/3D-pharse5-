# Korean Arena Phase3A Living NPC World

Run python3 start_review.py and open http://127.0.0.1:4378/REVIEW.html. Actual local compiled Phaser with canonical frozen world,12original players,28cosmetics and14newresidents. No Node,install or network required to play. --lan explicitly opts into your own LAN only.

All14resident gameplay videos,native crops and review sheets included. Large full traversal/stability videos and native scene PNGs resolve online at the immutable review tag. Native PNGs are pixel authority.

Human artistic/linguistic approval PENDING. Physical devices and hardwareGPU NOT TESTED. Phase3B locked. No main merge/public deployment.
