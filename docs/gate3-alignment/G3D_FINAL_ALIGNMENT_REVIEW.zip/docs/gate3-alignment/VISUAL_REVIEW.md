# Native visual review

[Open full gallery](VISUAL_REVIEW.html) · [Decision/status](README.md) · [QA](QA.md). All JPEGs are review derivatives under1MB; original Phaser PNGs are unchanged. Human acceptance pending; station residuals and protected planning decisions remain.

## palace-compound

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/palace-compound-before-native.png) · [After native](palace-compound-after-native.png)

![BEFORE left / AFTER right](palace-compound-comparison.jpg)

## palace-entrance

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/palace-entrance-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/palace-entrance-after-native.png)

![BEFORE left / AFTER right](palace-entrance-comparison.jpg)

## palace-east

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/palace-east-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/palace-east-after-native.png)

![BEFORE left / AFTER right](palace-east-comparison.jpg)

## palace-route

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/palace-route-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/palace-route-after-native.png)

![BEFORE left / AFTER right](palace-route-comparison.jpg)

## station-precinct

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/station-precinct-before-native.png) · [After native](station-precinct-after-native.png)

![BEFORE left / AFTER right](station-precinct-comparison.jpg)

## station-upper

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/station-upper-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/station-upper-after-native.png)

![BEFORE left / AFTER right](station-upper-comparison.jpg)

## station-front

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/station-front-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/station-front-after-native.png)

![BEFORE left / AFTER right](station-front-comparison.jpg)

## station-right

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/station-right-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/station-right-after-native.png)

![BEFORE left / AFTER right](station-right-comparison.jpg)

## retail-block

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/retail-block-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/retail-block-after-native.png)

![BEFORE left / AFTER right](retail-block-comparison.jpg)

## cafe-roof

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/cafe-roof-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/cafe-roof-after-native.png)

![BEFORE left / AFTER right](cafe-roof-comparison.jpg)

## bookshop-roof

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/bookshop-roof-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/bookshop-roof-after-native.png)

![BEFORE left / AFTER right](bookshop-roof-comparison.jpg)

## learning-roof

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/learning-roof-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/learning-roof-after-native.png)

![BEFORE left / AFTER right](learning-roof-comparison.jpg)

## bridge-mainland

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/bridge-mainland-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/bridge-mainland-after-native.png)

![BEFORE left / AFTER right](bridge-mainland-comparison.jpg)

## bridge-island

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/bridge-island-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/bridge-island-after-native.png)

![BEFORE left / AFTER right](bridge-island-comparison.jpg)

## bridge-full

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/bridge-full-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-alignment-review-20261024/docs/gate3-alignment/bridge-full-after-native.png)

![BEFORE left / AFTER right](bridge-full-comparison.jpg)
