# Phase1 technical review / roster INCOMPLETE

Run `python3 start_review.py`, open localhost. Default index is the actual approved world and character selector. Juni is complete; three new references are NOT playable. No account, Phase2 or deployment. Open REVIEW.html for native evidence/QA/device checklist. WASD/arrows, Shift, E, Space wave, C celebrate, mobile joystick retained. Settings -> character selection preserves current location. Actual phones/hardware NOT TESTED.
