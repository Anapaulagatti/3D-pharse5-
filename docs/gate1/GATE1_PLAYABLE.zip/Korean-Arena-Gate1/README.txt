KOREAN ARENA — GATE1 VISUAL SAMPLE, USER APPROVAL PENDING
Extract and run python3 start.py (Windows: py start.py). Python3 required, no Node needed.
WASD/arrows walk, Shift runs, E opens a venue card, Space greets. Landscape mobile has joystick and interaction button.
Four new original buildings, one continuous sidewalk and public gathering court. No full-world rebuild or deployment.
Default1x camera follows Juni; add ?overview to the printed URL for the complete native1536x1024 scene (large display recommended).
