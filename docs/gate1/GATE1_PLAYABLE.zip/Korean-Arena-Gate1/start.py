import argparse,functools,http.server,pathlib,webbrowser
p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8080);p.add_argument('--no-browser',action='store_true');a=p.parse_args()
class Handler(http.server.SimpleHTTPRequestHandler):
 def end_headers(self):self.send_header('Cache-Control','no-store');super().end_headers()
base=pathlib.Path(__file__).resolve().parent/'site'
with http.server.ThreadingHTTPServer(('127.0.0.1',a.port),functools.partial(Handler,directory=str(base)))as server:
 url=f'http://127.0.0.1:{server.server_port}/3D-pharse5-/gate1-street.html';print(url,flush=True)
 if not a.no_browser:webbrowser.open(url)
 try:server.serve_forever()
 except KeyboardInterrupt:pass
