import argparse,http.server,pathlib
p=argparse.ArgumentParser();p.add_argument("--port",type=int,default=0);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parent
handler=lambda *args,**kw:http.server.SimpleHTTPRequestHandler(*args,directory=str(root),**kw)
server=http.server.ThreadingHTTPServer(("127.0.0.1",a.port),handler)
print(f"http://127.0.0.1:{server.server_port}/3D-pharse5-/world-gate1.html",flush=True)
try:server.serve_forever()
except KeyboardInterrupt:server.server_close()
