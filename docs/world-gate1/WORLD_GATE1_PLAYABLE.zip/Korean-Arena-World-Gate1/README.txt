KOREAN ARENA — NEW WORLD GATE 1 ONLY
Unzip, run python3 start.py (Windows: py start.py), open the printed URL.
WASD/arrows walk; Shift run; E inspect. Mobile landscape touch joystick.
Use Overview link for zoning. All geometry is planning graybox, NOT final art.
Style-bible link includes old street/north reference images, not old-world runtime.
No Gate2/Gate3 work, no approval, no deployment.
