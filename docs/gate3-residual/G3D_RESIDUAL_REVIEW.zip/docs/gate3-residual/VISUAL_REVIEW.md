# Consolidated native visual review

[Playable ZIP](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/G3D_RESIDUAL_REVIEW.zip) · [Full gallery](VISUAL_REVIEW.html) · [Decisions](README.md) · [QA](QA.md). JPEG previews under1MB; native PNGs unchanged. No human acceptance inferred from tests.

## palace-compound

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/palace-compound-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/palace-compound-after-native.png)

![BEFORE left / AFTER right](palace-compound-comparison.jpg)

## palace-entrance

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/palace-entrance-before-native.png) · [After native](palace-entrance-after-native.png)

![BEFORE left / AFTER right](palace-entrance-comparison.jpg)

## palace-route

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/palace-route-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/palace-route-after-native.png)

![BEFORE left / AFTER right](palace-route-comparison.jpg)

## palace-east

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/palace-east-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/palace-east-after-native.png)

![BEFORE left / AFTER right](palace-east-comparison.jpg)

## archive-corridor

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/archive-corridor-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/archive-corridor-after-native.png)

![BEFORE left / AFTER right](archive-corridor-comparison.jpg)

## station-precinct

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-precinct-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-precinct-after-native.png)

![BEFORE left / AFTER right](station-precinct-comparison.jpg)

## station-upper

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-upper-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-upper-after-native.png)

![BEFORE left / AFTER right](station-upper-comparison.jpg)

## station-front

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-front-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-front-after-native.png)

![BEFORE left / AFTER right](station-front-comparison.jpg)

## station-right

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-right-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-right-after-native.png)

![BEFORE left / AFTER right](station-right-comparison.jpg)

## station-tree

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-tree-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-tree-after-native.png)

![BEFORE left / AFTER right](station-tree-comparison.jpg)

## retail-block

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/retail-block-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/retail-block-after-native.png)

![BEFORE left / AFTER right](retail-block-comparison.jpg)

## cafe-roof

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/cafe-roof-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/cafe-roof-after-native.png)

![BEFORE left / AFTER right](cafe-roof-comparison.jpg)

## bookshop-roof

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/bookshop-roof-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/bookshop-roof-after-native.png)

![BEFORE left / AFTER right](bookshop-roof-comparison.jpg)

## learning-roof

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/learning-roof-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/learning-roof-after-native.png)

![BEFORE left / AFTER right](learning-roof-comparison.jpg)

## bridge-mainland

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/bridge-mainland-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/bridge-mainland-after-native.png)

![BEFORE left / AFTER right](bridge-mainland-comparison.jpg)

## bridge-island

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/bridge-island-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/bridge-island-after-native.png)

![BEFORE left / AFTER right](bridge-island-comparison.jpg)

## coast-west

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/coast-west-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/coast-west-after-native.png)

![BEFORE left / AFTER right](coast-west-comparison.jpg)

## coast-middle

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/coast-middle-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/coast-middle-after-native.png)

![BEFORE left / AFTER right](coast-middle-comparison.jpg)

## coast-east

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/coast-east-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/coast-east-after-native.png)

![BEFORE left / AFTER right](coast-east-comparison.jpg)

## bridge-full

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/bridge-full-before-native.png) · [After native](bridge-full-after-native.png)

![BEFORE left / AFTER right](bridge-full-comparison.jpg)

## Unadopted proposals

### station-front / road

[Current native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-front-after-native.png) · [Proposed native](station-front-road-proposal-native.png)

![Current left / proposal right](station-front-road-comparison.jpg)

### station-precinct / road

[Current native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-precinct-after-native.png) · [Proposed native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/station-precinct-road-proposal-native.png)

![Current left / proposal right](station-precinct-road-comparison.jpg)

### archive-corridor / gate

[Current native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/archive-corridor-after-native.png) · [Proposed native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/archive-corridor-gate-proposal-native.png)

![Current left / proposal right](archive-corridor-gate-comparison.jpg)

### palace-east / gate

[Current native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/palace-east-after-native.png) · [Proposed native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/palace-east-gate-proposal-native.png)

![Current left / proposal right](palace-east-gate-comparison.jpg)

[Bridge support geometry overlay, not applied](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-residual-review-20261025/docs/gate3-residual/bridge-full-geometry-proposal-native.png) · [Exact proposal](bridge-clearance-proposal.json) · [Actual video](world-traversal-review.mp4).
