Korean Arena — THREE STATIC CHARACTER CONCEPTS, A/B/C. NOT APPROVED OR PUBLICLY RELEASED.
Choose front/back/left/right and 1x native / 2x gameplay camera. These are static direction drawings, not action animations. The current game is preserved and linked separately; its old actors have been rejected and await a future approved replacement.
Extract, run python3 start.py (Windows py start.py), open printed HTTP URL. Python 3 required; no Node needed to view. Do not open HTML as source or file://. Ctrl+C stops. No online users, paid services or ads.
