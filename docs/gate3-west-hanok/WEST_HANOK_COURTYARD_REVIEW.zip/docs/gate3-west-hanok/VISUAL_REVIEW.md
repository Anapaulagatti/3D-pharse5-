# Western hanok +lower courtyard — native Phaser review

Hanbit Station and BOTH Jeju bridge visuals are HUMAN APPROVED AND LOCKED. These2 local repairs await human review. Collision is EXACT unchanged.

[Playable ZIP](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-west-hanok-court-review-20261025/docs/gate3-west-hanok/WEST_HANOK_COURTYARD_REVIEW.zip) · [QA](QA.md) · [Actual public-route controls](world-traversal-review.mp4)

## house

![Before/after](house-comparison.jpg)

[BEFORE native1x](house-before-native-1x.png) · [AFTER native1x](house-after-native-1x.png) · [Native comparison board](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-west-hanok-court-review-20261025/docs/gate3-west-hanok/house-before-after-native-board.png)

![Enlarged nearest review](house-enlarged-review.jpg)

## courtyard

![Before/after](courtyard-comparison.jpg)

[BEFORE native1x](courtyard-before-native-1x.png) · [AFTER native1x](courtyard-after-native-1x.png) · [Native comparison board](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-west-hanok-court-review-20261025/docs/gate3-west-hanok/courtyard-before-after-native-board.png)

![Enlarged nearest review](courtyard-enlarged-review.jpg)

## Combined local area

![Combined](combined-local-review.jpg)

[Unannotated native1x local screenshot](combined-local-after-native-1x.png) · [Full original native Phaser frame](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-west-hanok-court-review-20261025/docs/gate3-west-hanok/west-both-local-after-native.png)

## Scope / gameplay

[Native pixel audit](scope-and-collision.json) · [Protected hashes](protected-hashes.json) · [Movement QA](body-clearance.json) · [Gameplay video](world-traversal-review.mp4)
