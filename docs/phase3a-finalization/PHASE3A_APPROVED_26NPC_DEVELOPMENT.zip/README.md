# Approved 26-NPC development baseline

Extract the ZIP and run python3 start_review.py. Open the printed local REVIEW.html.
No Node installation or network is required for gameplay. --lan is optional private-LAN review, not public deployment.

Ordinary development gameplay registers 26 actors: 14 residents, six original visitors and six educational archive reconstructions. Fresh storage opens the unchanged Character Studio; choose one of the twelve characters and enter the world. Visit palace, bookshop or coast contexts and open the History Archive. No QA/historyArtReview flag is required. At most four actors and four textures are active, with two pending loads; one reconstruction temporarily replaces a host slot.

All approved NPC art, animation, world, players and cosmetics are unchanged. Historical names are retained, with zero fictional replacements. Names are separate from stable IDs. Commercial rights are NOT certified: applicable generation terms, jurisdiction and likeness review remain pending. Unverified biographies and real-person fact cards are excluded. No authentic quotation or completed lesson is invented.

Native crops, an actual ordinary-world gameplay video, rights matrix, QA and handoff are included locally. Optional full-resolution PNG/source links point to the immutable online checkpoint. Physical Android, iPhone and hardware GPU remain NOT TESTED. Existing warnings are retained. Phase 3B is an architectural handoff only; no implementation, main merge or deployment is authorized.
