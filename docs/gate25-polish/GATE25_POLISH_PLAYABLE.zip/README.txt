GATE2.5 FINAL VISUAL POLISH REVIEW / Gate3 LOCKED
Run python3 start.py and open the printed URL. For a physical phone on the same trusted Wi-Fi run python3 start.py --lan and substitute your computer's LAN IP. No public deployment.
Choose Polished district for completed terrain/seams and whole original props; C Jeju for4-stop tour at50% with distinct coast/oreum views and quiet gutter controls. Previous scenes retained as history.
WASD/arrows; Shift run; E explore; mobile joystick/Run/Explore.
Scenic: drag/pinch, Full scene, Start Tour. Tour: Pause/Resume, Skip landmark, Return to Juni. Paused tour permits manual camera exploration. Movement intent cancels auto camera; Return never teleports Juni. Reduced motion uses static selection. Regular follow remains native1:1.
Options (...) > Export test report downloads real client/viewport/raw update timing/chunk diagnostics; user must explicitly identify physical device. Emulation is not physical validation.
District retains3 bounded native ground chunks, adjacent prefetch, no repeat requests; not general full-world streaming. Missing background and two joins received localized art, original facades/Juni/coordinates preserved. Tour controls collapse after2.4s; visible landmark Controls restores, or tap scene. Reduced motion/focus keeps controls visible.
Jeju bridge/mainland are labeled technical geometry, not final production bridge art. Water between landing areas is blocked. No train/ferry gameplay.
Read MOBILE_CHECKLIST.md, DEVICE_TESTING.md and REPORT.md. Human UX/visual review and physical acceptance pending. STOP / no Gate3, merge or public deployment.
