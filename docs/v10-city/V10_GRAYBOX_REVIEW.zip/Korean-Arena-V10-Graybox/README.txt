V10 PLAYABLE GRAYBOX — awaiting masterplan and graybox approval.
Extract, enter this folder, run python3 start.py (Windows: py start.py).
WASD/arrows walk, Shift runs, E interacts; touch joystick on landscape mobile.
No final southern artwork has been generated. No public deployment.
