# Executed validation

| Command | Result | Log |
|---|---|---|
| npm run typecheck | PASS | [log](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase2a-character-studio-review-20261026/docs/phase2a/validation-logs/typecheck.txt) |
| npm run assets:check | PASS | [log](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase2a-character-studio-review-20261026/docs/phase2a/validation-logs/assets-check.txt) |
| npm run lint | PASS | [log](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase2a-character-studio-review-20261026/docs/phase2a/validation-logs/lint.txt) |
| npm run test |68 PASS | [log](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase2a-character-studio-review-20261026/docs/phase2a/validation-logs/unit.txt) |
| npm run test:e2e |32 PASS | [log](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase2a-character-studio-review-20261026/docs/phase2a/validation-logs/e2e.txt) |
| npm run build | PASS | [log](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase2a-character-studio-review-20261026/docs/phase2a/validation-logs/build.txt) |

The full E2E run preceded the final landscape-resize handler; its targeted mobile/orientation regression subsequently passed [1 test](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase2a-character-studio-review-20261026/docs/phase2a/validation-logs/mobile-rotation.txt). Final typecheck/unit/lint were rerun. Source source-atlas bytes did not change during evidence/report preparation.

The portable compiled build [passed](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase2a-character-studio-review-20261026/docs/phase2a/validation-logs/portable-build.txt). The actual extracted package [passed](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase2a-character-studio-review-20261026/docs/phase2a/validation-logs/package-smoke.txt) all six identities, all four cosmetic presets, real movement, visited/position retention after reload and mobile touch controls with no missing requests or page errors. The final ZIP only adds evidence/documents to that tested runtime; every runtime/build file is byte-compared again after packaging.

[Protected hashes](protected-audit.json), [native actual Phaser readbacks](native-pixel-qa.json), [composition ownership](composition-qa.json), [package smoke data](package-smoke.json). Physical devices remain NOT TESTED.
