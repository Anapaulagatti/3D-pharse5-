# Korean Arena Phase2A Character Studio

Run python3 start_review.py and open REVIEW.html. This is the actual compiled Phaser game with the frozen canonical world, six playable characters and native-frame cosmetics. The game runs locally/offline; full authoring sources and large native evidence are linked to the immutable source checkpoint.

Four original identities are human-approved and unchanged. Ara/Doyun and cosmetics are review candidates with native/technical validation, awaiting human Phase2A approval. Physical Android/iPhone and hardware performance NOT TESTED. No Phase2B, main merge or public deployment.
