# Phase 3B-A PRIVATE REVIEW
Extract and run python3 start_review.py. Open the printed localhost REVIEW.html.
No Node/install/network is required for gameplay. --lan is explicit private-LAN review, not public deployment.
Fresh storage uses the unchanged 12-character Studio. Choose a character and Enter World. The world has 20 present-day schedule identities and six selected fictional era-story inhabitants (26 stable IDs). Caps remain 4 actors / 4 textures / 2 pending loads.
The normal day lasts 30 real minutes. Use a QA approach link and Settings clock controls for acceleration. A review link can inspect a visitor outside its normal window; this is not ordinary eligibility. Source artwork, avatars, cosmetics, map and collision remain unchanged.
Native crops, actual videos and rights/QA documents are local. Full native originals, verbose source evidence and historical provenance links are optional online checkpoint files.
All26commercial publications remain blocked pending creation/account terms and independent IP review. Fictional names or AI generation do not grant clearance. This is a technical review, not legal certification. Physical Android/iPhone/hardware GPU NOT TESTED; measured browser outliers remain documented.
No shops/farming gameplay/economy/learning rewards/ads/multiplayer or Phase3B-B/C/D. No main merge or public deployment.
