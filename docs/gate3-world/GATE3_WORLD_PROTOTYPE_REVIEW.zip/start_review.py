from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import argparse,os
p=argparse.ArgumentParser();p.add_argument("--lan",action="store_true");p.add_argument("--port",type=int,default=4294);a=p.parse_args();os.chdir(Path(__file__).resolve().parent);host="0.0.0.0"if a.lan else"127.0.0.1";print(f"Local review: http://127.0.0.1:{a.port}/");print("LAN option: use this computer's private LAN IP on the phone; physical tests remain NOT TESTED until recorded."if a.lan else"Use --lan only for private local-network device review.");ThreadingHTTPServer((host,a.port),SimpleHTTPRequestHandler).serve_forever()
