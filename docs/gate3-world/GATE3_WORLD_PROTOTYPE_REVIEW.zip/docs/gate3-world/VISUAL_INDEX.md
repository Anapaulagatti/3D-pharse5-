# Direct visual review links

Every original is an actual1280×900 native Phaser capture, zoom1, DPR1. JPEG copies are under1MB viewing aids. No artistic acceptance is implied.

![Scaled world overview](world-overview-review.jpg)

| Region | Lightweight preview | Original native1:1 |
|---|---|---|
| palace | [Preview](palace-native-review.jpg) | [Native PNG](palace-native.png) |
| academy | [Preview](academy-native-review.jpg) | [Native PNG](academy-native.png) |
| archive | [Preview](archive-native-review.jpg) | [Native PNG](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3c-full-world-prototype-20261023/docs/gate3-world/archive-native.png) |
| culture | [Preview](culture-native-review.jpg) | [Native PNG](culture-native.png) |
| transition | [Preview](transition-native-review.jpg) | [Native PNG](transition-native.png) |
| retail | [Preview](retail-native-review.jpg) | [Native PNG](retail-native.png) |
| station | [Preview](station-native-review.jpg) | [Native PNG](station-native.png) |
| platform | [Preview](platform-native-review.jpg) | [Native PNG](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3c-full-world-prototype-20261023/docs/gate3-world/platform-native.png) |
| namsan | [Preview](namsan-native-review.jpg) | [Native PNG](namsan-native.png) |
| maru | [Preview](maru-native-review.jpg) | [Native PNG](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3c-full-world-prototype-20261023/docs/gate3-world/maru-native.png) |
| amusement | [Preview](amusement-native-review.jpg) | [Native PNG](amusement-native.png) |
| market | [Preview](market-native-review.jpg) | [Native PNG](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3c-full-world-prototype-20261023/docs/gate3-world/market-native.png) |
| waterfront | [Preview](waterfront-native-review.jpg) | [Native PNG](waterfront-native.png) |
| ferry | [Preview](ferry-native-review.jpg) | [Native PNG](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3c-full-world-prototype-20261023/docs/gate3-world/ferry-native.png) |
| jeju | [Preview](jeju-native-review.jpg) | [Native PNG](jeju-native.png) |
| oreum | [Preview](oreum-native-review.jpg) | [Native PNG](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3c-full-world-prototype-20261023/docs/gate3-world/oreum-native.png) |
| house | [Preview](house-native-review.jpg) | [Native PNG](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3c-full-world-prototype-20261023/docs/gate3-world/house-native.png) |

[Actual scaled Phaser overview](world-overview-phaser.png) · [Actual gameplay review video](world-traversal-review.mp4) · [Full native gameplay recording](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3c-full-world-prototype-20261023/docs/gate3-world/world-traversal.mp4)
