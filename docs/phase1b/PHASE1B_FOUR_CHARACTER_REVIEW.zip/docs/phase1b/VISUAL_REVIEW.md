# Native visual review

Order throughout: **Juni · Haneul · Bomi · Minjun**. Native PNGs are unscaled Phaser backing images; review enlargements use integer nearest sampling. Source sheets are labelled separately from gameplay. Videos are actual browser recordings; H264 review copies are lossy and do not substitute for native pixel evidence.

![Source lineup4×](lineup-review-4x.png)

**Lossless atlas animations, source review only (not gameplay).** Columns: Juni/Haneul/Bomi/Minjun. Rows: front/back/left/right. The images animate in compatible browsers; [native walk](walk-four-directions-native-preview.png) and [native run](run-four-directions-native-preview.png) remain1×. [Pose-key provenance](motion-preview-provenance.json) explains the intended contact/crossing phases and retains all Forge warnings.

![Walk, four directions, source2× nearest](walk-four-directions-review-2x-preview.png)

![Run, four directions, source2× nearest](run-four-directions-review-2x-preview.png)

[Native source lineup1×](lineup-native-1x.png) · [Actual Phaser body readback lineup1×](actual-phaser-body-lineup-native.png) · [Actual scene crops1×](four-native-gameplay-crops.png)

![Actual Phaser crops2×](four-gameplay-crops-2x.png)

[Native-pixel gameplay focus crop, all four characters / walk / run / emotes](four-character-gameplay-native-crop-review.mp4) · [Uncropped UI review video](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/four-character-gameplay-review.mp4) · [Full recording](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/four-character-gameplay.mp4)

[Actual nonempty visited marker, four character switches and refresh — lightweight video](progress-switch-refresh-review.mp4) · [Full recording](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/progress-switch-refresh.mp4)

## Juni

![Desktop selection](selection-juni-desktop.jpg)

![Mobile landscape browser selection](selection-juni-mobile-landscape.jpg)

[Complete station frontage, native1:1](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/juni-complete-station-frontage-native-1x.png) · [Native scene crop](juni-station-native-crop.png) · [Both bridges, actual out/return gameplay](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bridges-juni-review.mp4) · [Full bridge recording](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bridges-juni.mp4)

## Haneul

![Desktop selection](selection-haneul-desktop.jpg)

![Mobile landscape browser selection](selection-haneul-mobile-landscape.jpg)

[Complete station frontage, native1:1](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-complete-station-frontage-native-1x.png) · [Native scene crop](haneul-station-native-crop.png) · [Both bridges, actual out/return gameplay](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bridges-haneul-review.mp4) · [Full bridge recording](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bridges-haneul.mp4)

[Native atlas](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/public/assets/characters/haneul/atlas.png) · [Phaser JSON](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/public/assets/characters/haneul/atlas.json) · [Sources / masks / joints / provenance](../../assets-src/characters/phase1b/haneul/provenance.json)

- [walk front: eight native source frames](haneul-walk-front-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-walk-front-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-walk-front-native-1x.png)
- [walk back: eight native source frames](haneul-walk-back-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-walk-back-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-walk-back-native-1x.png)
- [walk left: eight native source frames](haneul-walk-left-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-walk-left-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-walk-left-native-1x.png)
- [walk right: eight native source frames](haneul-walk-right-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-walk-right-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-walk-right-native-1x.png)
- [run front: eight native source frames](haneul-run-front-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-run-front-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-run-front-native-1x.png)
- [run back: eight native source frames](haneul-run-back-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-run-back-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-run-back-native-1x.png)
- [run left: eight native source frames](haneul-run-left-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-run-left-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-run-left-native-1x.png)
- [run right: eight native source frames](haneul-run-right-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-run-right-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-run-right-native-1x.png)

[Wave native sheet](haneul-wave-sheet-native.png) · [Celebrate native sheet](haneul-celebrate-sheet-native.png) · [Wave actual Phaser](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-wave-native-1x.png) · [Celebrate actual Phaser](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/haneul-celebrate-native-1x.png)

## Bomi

![Desktop selection](selection-bomi-desktop.jpg)

![Mobile landscape browser selection](selection-bomi-mobile-landscape.jpg)

[Complete station frontage, native1:1](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-complete-station-frontage-native-1x.png) · [Native scene crop](bomi-station-native-crop.png) · [Both bridges, actual out/return gameplay](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bridges-bomi-review.mp4) · [Full bridge recording](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bridges-bomi.mp4)

[Native atlas](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/public/assets/characters/bomi/atlas.png) · [Phaser JSON](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/public/assets/characters/bomi/atlas.json) · [Sources / masks / joints / provenance](../../assets-src/characters/phase1b/bomi/provenance.json)

- [walk front: eight native source frames](bomi-walk-front-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-walk-front-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-walk-front-native-1x.png)
- [walk back: eight native source frames](bomi-walk-back-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-walk-back-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-walk-back-native-1x.png)
- [walk left: eight native source frames](bomi-walk-left-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-walk-left-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-walk-left-native-1x.png)
- [walk right: eight native source frames](bomi-walk-right-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-walk-right-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-walk-right-native-1x.png)
- [run front: eight native source frames](bomi-run-front-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-run-front-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-run-front-native-1x.png)
- [run back: eight native source frames](bomi-run-back-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-run-back-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-run-back-native-1x.png)
- [run left: eight native source frames](bomi-run-left-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-run-left-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-run-left-native-1x.png)
- [run right: eight native source frames](bomi-run-right-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-run-right-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-run-right-native-1x.png)

[Wave native sheet](bomi-wave-sheet-native.png) · [Celebrate native sheet](bomi-celebrate-sheet-native.png) · [Wave actual Phaser](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-wave-native-1x.png) · [Celebrate actual Phaser](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bomi-celebrate-native-1x.png)

## Minjun

![Desktop selection](selection-minjun-desktop.jpg)

![Mobile landscape browser selection](selection-minjun-mobile-landscape.jpg)

[Complete station frontage, native1:1](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-complete-station-frontage-native-1x.png) · [Native scene crop](minjun-station-native-crop.png) · [Both bridges, actual out/return gameplay](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bridges-minjun-review.mp4) · [Full bridge recording](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/bridges-minjun.mp4)

[Native atlas](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/public/assets/characters/minjun/atlas.png) · [Phaser JSON](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/public/assets/characters/minjun/atlas.json) · [Sources / masks / joints / provenance](../../assets-src/characters/phase1b/minjun/provenance.json)

- [walk front: eight native source frames](minjun-walk-front-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-walk-front-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-walk-front-native-1x.png)
- [walk back: eight native source frames](minjun-walk-back-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-walk-back-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-walk-back-native-1x.png)
- [walk left: eight native source frames](minjun-walk-left-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-walk-left-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-walk-left-native-1x.png)
- [walk right: eight native source frames](minjun-walk-right-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-walk-right-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-walk-right-native-1x.png)
- [run front: eight native source frames](minjun-run-front-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-run-front-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-run-front-native-1x.png)
- [run back: eight native source frames](minjun-run-back-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-run-back-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-run-back-native-1x.png)
- [run left: eight native source frames](minjun-run-left-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-run-left-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-run-left-native-1x.png)
- [run right: eight native source frames](minjun-run-right-sheet-native.png) · [2× review](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-run-right-sheet-2x.png) · [Actual Phaser1× pose](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-run-right-native-1x.png)

[Wave native sheet](minjun-wave-sheet-native.png) · [Celebrate native sheet](minjun-celebrate-sheet-native.png) · [Wave actual Phaser](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-wave-native-1x.png) · [Celebrate actual Phaser](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/phase1b-roster-review-20261026/docs/phase1b/minjun-celebrate-native-1x.png)

## Preserved world

[Native Canvas/WebGL comparison report](native-pixel-qa.json). Current palace, station and bridge reference entries match accepted Phase1 world pixels exactly under the same camera/browser configuration; original comparison images remain unchanged in docs/phase1.

[QA / exact warning values](QA.md) · [Physical-device review](DEVICE_REVIEW.md).
