# Phase1B four-character playable review candidate

Run `python3 start_review.py` and open localhost. Actual production index loads the frozen canonical world, four genuine atlases and original controls. Settings -> Chon nhan vat. WASD/arrows, Shift run, Space wave, C celebrate; mobile landscape joystick. Same-page refresh retains character, position and existing visited markers when browser storage is available. Explicit review-entry navigation keeps its spawn. Open REVIEW.html for QA, native source/crop evidence and actual videos. Large native world readbacks and full recordings use immutable evidence links. All runtime dependencies and character source packs are included offline.

Human character-art approval PENDING. Auto near/far classification WARNs retained. Physical Android/iPhone and hardware performance NOT TESTED. Canonical world has no interior transition. No Phase2, main merge or public deployment.
