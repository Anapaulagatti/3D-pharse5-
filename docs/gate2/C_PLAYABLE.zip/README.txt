GATE 2 / slice C / human artistic approval pending
Run: python3 start.py
Open: http://127.0.0.1:8062/3D-pharse5-/gate2-review.html?scene=c
Only a local static server; no network install, no public deployment.
WASD/arrows move, Shift runs, E explores, Space greets; mobile landscape joystick + buttons.
Canvas is native 1:1; screenshot URLs append &native&overview.
Includes: c. Juni atlas unchanged. No QA hook on normal entry.
Jeju native-scale reservation FAIL: localized proposal only, approved map unchanged.
B deliberately retains approved Muneum artwork; station is new supporting study.
This package does not unlock Gate3 or integrate/replace the full world.
