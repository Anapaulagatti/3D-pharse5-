from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import os,sys
os.chdir(Path(__file__).resolve().parent)
port=int(sys.argv[1]) if len(sys.argv)>1 else 8064
print(f"Open http://127.0.0.1:{port}/3D-pharse5-/gate2-review.html?scene=original",flush=True)
ThreadingHTTPServer(("127.0.0.1",port),SimpleHTTPRequestHandler).serve_forever()
