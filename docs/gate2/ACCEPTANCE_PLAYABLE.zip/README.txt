Gate2 acceptance review only / Gate3 locked / human artistic approval pending
Run python3 start.py then open the local URL printed. No dependencies to install.
Select Original for the ONE new bakery; Station for exact-fit entrance; Join proof for Muneum/station; Jeju fit for the CANDIDATE technical graybox registration. A/B/C/transition retain their source art.
WASD/arrows move; Shift runs; E explores; Space greets.
Mobile landscape: joystick, Run, Explore. Scenic freezes player control; drag/pinch to look. Full scene shows current Juni, landmarks and previous follow viewport. Return to Juni restores native gameplay. Reduced views are not native1:1 art evidence.
Options (...) contains Pause and OPTIONAL Landmark moments, off by default. Movement or Skip cancels the showcase; reduced motion suppresses it.
No ferry gameplay, full-world production, public deployment or main merge.
The approved masterplan/checkpoint and source images are unchanged. Fit candidate and judgments require human review. No physical-device performance certification.
