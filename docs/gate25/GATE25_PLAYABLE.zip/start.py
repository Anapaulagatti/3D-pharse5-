from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import argparse,os
p=argparse.ArgumentParser();p.add_argument('--lan',action='store_true');p.add_argument('--port',type=int,default=8065);args=p.parse_args()
os.chdir(Path(__file__).resolve().parent)
host='0.0.0.0' if args.lan else '127.0.0.1'
print(f"Open http://{'COMPUTER_LAN_IP' if args.lan else host}:{args.port}/3D-pharse5-/gate2-review.html?scene=c",flush=True)
print('Gate2.5 private test only / Gate3 locked / Ctrl-C stops the server',flush=True)
ThreadingHTTPServer((host,args.port),SimpleHTTPRequestHandler).serve_forever()
