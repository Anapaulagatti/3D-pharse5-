GATE2.5 PRIVATE REVIEW / Gate3 LOCKED
Run python3 start.py and open the printed URL. For a physical phone on the same trusted Wi-Fi run python3 start.py --lan and substitute your computer's LAN IP. No public deployment.
Choose C Jeju for full4-stop tour, B Muneum for one short reusable tour demo, Gate2.5 district for3 independent native sources, Gate2.5 Jeju expansion for approved localized working plan. Previous scenes retained.
WASD/arrows; Shift run; E explore; mobile joystick/Run/Explore.
Scenic: drag/pinch, Full scene, Start Tour. Tour: Pause/Resume, Skip landmark, Return to Juni. Paused tour permits manual camera exploration. Movement intent cancels auto camera; Return never teleports Juni. Reduced motion uses static selection. Regular follow remains native1:1.
Options (...) > Export test report downloads real client/viewport/raw update timing/chunk diagnostics; user must explicitly identify physical device. Emulation is not physical validation.
District retains3 bounded native ground chunks, adjacent prefetch, no repeat requests; not general full-world streaming. Unpainted nonwalkable top/bottom margins and some pavement/road material differences remain disclosed. No replacement art.
Jeju bridge/mainland are labeled technical geometry, not final production bridge art. Water between landing areas is blocked. No train/ferry gameplay.
Read DEVICE_TESTING.md and REPORT.md. Human UX/visual review and physical acceptance pending. STOP / no Gate3, merge or public deployment.
