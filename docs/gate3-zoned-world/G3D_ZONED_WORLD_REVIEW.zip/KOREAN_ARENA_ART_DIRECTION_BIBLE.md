# Active refinement — regional land use and urban landscape zoning

The full G3-D composition remains human REJECTED pending zoning correction. [Shared landscape plan](docs/gate3-zoned-world/LANDSCAPE_MASTERPLAN.md) and [global native material registry](assets-src/gate3/zoned-world-v1/land-use-registry.json) govern adjacent environment ownership. Commercial/transit/attraction spaces use open fine granite paving and restrained formal beds, not forest carpet. Namsan retains accepted layered forest; historic north retains Korean courts/gardens; canonical Jeju stays immutable. New water transitions operate outside its original rectangle with native source-texel ownership; no landscape-atlas filling or source filtering. Technical readback never grants artistic acceptance.

# Korean Arena Art Direction Bible — recovery version1

**Current authority:** [conditional shared-system approval and controlled world recovery](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/docs/current/G3D_WORLD_RECOVERY_AUTHORIZATION.md). The three pilots established the shared direction; controlled propagation to all ten regions is authorized. Individual scenes/landmarks and the consolidated world still require human artistic acceptance. The G3-B/C engine is retained; its rejected giant repeating material atlas remains a historical comparison, never a style reference.

The consolidated implementation uses [versioned native sources and provenance](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/assets-src/gate3/recovery-world-v1/integration-provenance.json) and [review evidence](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/docs/gate3-recovery-world/README.md). Native regional plates have binary ownership masks; all runtime chunks remain1:1. Original historical A, Jeju C and canonical station floor remain exact. Deep open water alone reuses the approved Jeju128px fine-wave component at native scale/global phase, excluding the entire original island and authored coast within160px of land; it is not the rejected landscape atlas. Ordinary native trees are extracted independently and placed in documented clusters. Complete tower/ride silhouettes are never shrunk or arbitrarily cropped to force a fit; projection and native entrance-scale conflicts remain explicit review items. The Bakery remains required/unplaced.

## Canonical sources, precedence and evidence

1. [Gate1 style direction](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/docs/world-gate1/style-bible.html) and [original Muneum Phaser sample](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/docs/gate1/GATE1_STREET_NATIVE.png): original architectural/detail intent, full-scale Juni, paths and scene craft.
2. [Approved historical north](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/public/assets/gate2/a/ground.png), its independent roof/pine layers and original walk mask: Korean identity, paving, garden enclosure, timber/roof relationships.
3. [Muneum street](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/public/assets/gate2/b/ground.png), [original Bakery](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/public/assets/gate3/registration/bakery.png), and [accepted seamless district source](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/assets-src/gate25-station-planters/final-clean-ground.png): contemporary facade richness, public-space composition, contact detail and intentionally connected scenes. The district floor's historical station softness is superseded by item4; do not copy it back.
4. [Hanbit Station](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/public/assets/gate3/registration/station.png), corrected independent planters, original BEFORE canopy and [approved restored floor](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/assets-src/gate3/forecourt-restoration/restored-ground.png), registry [approved-station-forecourt.json](assets-src/gate3/approved-station-forecourt.json): canonical station ownership and native ground fidelity.
5. [Approved Jeju](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/public/assets/gate2/c/ground.png) and its independent house entrance/orchard/roof objects: volcanic terrain, vegetation layers, stone-house identity and readable paths. Preserve it; do not repaint it toward rejected mainland terrain.

[Native calibration board](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/assets-src/gate3/recovery/canonical-native-board.png) contains actual unchanged source crops, a native Juni frame,189×196px approved tree and100×50px bench. It is an analysis board, not a new style painting. [Source boxes and hashes](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/assets-src/gate3/recovery/canonical-references.json) make it reproducible. Rejected G3-B atlases and coarse material tiles are comparison evidence only, never quality references. No V6–V10 southern artwork is a style source.

## Perspective and scale contract

- Fixed top-down3/4 orthographic-style projection; parallel facade/road axes, no district-specific horizon or vanishing point. Roof planes reveal depth while doors face the player. Do not flatten an elevation onto an unrelated ground angle.
- Juni remains the original96×112 atlas, foot anchor100/112, runtime scale1. Typical visible idle body is about80px; the animation's maximum visible width is49px. Atlas padding is not body size. Measure actual source frames beside art.
- Gate1's native door target is100–120px high. New public door openings target60–76px width so49px Juni has visible clearance. Existing approved door artwork stays unchanged. A40–65px tower doorway is a FAIL requiring newly authored native detail, not a smaller Juni.
- Use the approved100×50px bench and189×196px complete tree as ordinary scale exemplars. Ordinary standalone trees generally160–240px wide and180–280px tall; larger existing hero trees are scene-specific exceptions with complete supporting geometry, not a license for repeated300–500px atlas trees.
- Main routes retain approved144–176px reservations; new ordinary public sidewalks target≥96px clear. New local garden paths target80–112px where reserved space permits. Preserve approved narrower Jeju paths and audit their49px body clearance separately; do not silently widen the island.
- A contact footprint, visual roof projection, planted foundation edge and cast shadow are distinct owners. The facade can project north of a footprint; a stone support physically outside it needs documented collision ownership. Do not use reachability as facade-fit approval or a sprite rectangle as a solid wall.

## Native material grammar

| Family | Canonical native source | Measurable drawing target / variation |
|---|---|---|
| Historical courts | Approved north / Muneum garden stone | Ordinary stones roughly12–32px wide,8–18px tall,1–2px joints; restrained chips and1–3px grain clusters. Larger foundation blocks belong to architecture, not a repeated field. |
| Modern sidewalks | Original Muneum frontage | Similar fine joint density; warm neutral stone, deliberate curb/tactile/door thresholds, coherent longitudinal courses; no100px cobbles around full-size shops. |
| Roads / curbs | Muneum street and canonical station curb | Quiet1–2px aggregate, readable fine road lines, native6–12px curb faces; one continuous alignment across chunk boundaries. |
| Namsan soil / vegetation | Historical garden soil, approved Jeju layered slopes | Muted earth with finely clustered grasses, exposed roots and stone retaining contours; shade and elevation produce depth, not tiled flowers. |
| Garden paths | Historical court edges and Jeju route | Defined small stones/gravel with logical borders, stair/landing changes; variation follows slope/use, not random texture scattering. |
| Amusement walkways | Muneum shared public space | Same stone grammar, restrained park accents and readable entry circulation. Future propagation only after pilot approval. |
| Coastal basalt / ground | Approved Jeju | Columnar fractured basalt, irregular strata, fine path edges, rock/soil/plant contact and ocean foam. Do not recreate the approved island. |
| Harbor platform / timber | Approved district stone + Jeju bridge timber | Fine stone scales and native plank grain/fasteners; shadows/supports and shore contact must have spatial purpose. Future propagation only. |
| Grass / gravel / beds | Approved north/Muneum/Jeju gardens | Calm ground masses with deliberate low planting, local flower accents and visible soil; no repeated dense flower wallpaper, giant pebbles or random-noise finish. |

Material crops are **calibration samples, not repeating runtime tiles**. The recovery plates are authored at native world scale with contiguous variations and shared borders. [Versioned family registry](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-zoned-world-review-20261024/assets-src/gate3/recovery/material-system-v1.json) binds all pilots to these sources and tells the chunk builder which local regions depend on each family.

Known rejected material periods were232/238/240/244/248px. Inspect native homogeneous strips for correlation at those lags and obvious clone motifs. Natural stone-course periodicity at small joint spacing is different from copying a whole248px flower bed. Record autocorrelation and edge-detail measurements as diagnostics, not artistic PASS thresholds. Manual source-row joint measurements and1:1 side-by-side inspection remain required.

## Light, palette and ground contact

Warm daylight comes from upper left. Cast shadows generally extend down-right; use the approved scene as the local reference for length and contrast. Keep cool neutral roof shadows, warmly reflected stone and rich green foliage; avoid uniformly saturated red/yellow forests and heavy black illustration outlines absent from the approved scene.

A foundation darkens at its contact edge, casts a plausible short shadow and transitions into adjoining pavement/soil. Tree roots sit on receivers; a canopy is not a floating cutout. Texture contrast is subordinate to architectural readability. Preserve facade/interior glow already approved; never recolor approved images to match a poorer ground.

## Designed landscape and boundaries

Compose public circulation first, then terraces, retaining edges, low planting, mature trees and rest places. Ground changes occur at actual curbs, walls, contour lines, garden edges or designed paving transitions. Do not use an arbitrary rectangular field or oversized trees to hide a source boundary.

Namsan requires a readable hill/plateau, contour-following paths, layered plants and a credible full-size visitor entrance at the fixed tower position. Elevation painting does not claim3D climbing physics. North requires connected palace/courtyard/archive/workshop spaces and complete walls; do not join two independent palace plinths. South requires believable service/public-space distinctions and useful entrances.

Every independently sorted tree/structure must have a complete silhouette, explicit root/depth and physical foot ownership. Low painted ground cover may remain ground; tall baked canopies over walkable routes fail depth validation. Do not add unowned scenery and certify only the inherited mask.

## Production and validation rules

1. Retain the rejected G3-C prototype and all protected sources/checkpoints. Author only new versioned recovery assets and explicit edit/ownership masks. The accepted plan remains unchanged.
2. Author adjacent ground boundaries together; protect approved source pixels exactly. No global sharpening, blur, random-noise fill, stretching or fractional source resampling. Native renderer fixes, nearest sampling and station pivot policy stay intact.
3. Rebuild only chunks touched by the pilot masks. Keep physical/collision changes in a separate versioned record. Do not reopen the station strip or reactivate the rejected90×36 connector.
4. For North, South and Namsan show approved reference/current rejected/candidate, native Phaser shots, Juni beside architecture, source density/periodicity analysis and contact/seam crops. Mark unresolved criteria FAIL/PENDING even if build/hash/movement checks pass.
5. **One human approval gate for the unified system.** No full-world propagation until that approval. Then correct related source families/regions as one coordinated batch, retaining Bakery deferral and genuine P1 issues. No main merge, public deployment or physical-device PASS without recorded evidence.
