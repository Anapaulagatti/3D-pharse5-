from pathlib import Path
from argparse import ArgumentParser
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import os
p=ArgumentParser();p.add_argument('--port',type=int,default=4460);p.add_argument('--lan',action='store_true');a=p.parse_args();os.chdir(Path(__file__).resolve().parent)
print(f'Open http://127.0.0.1:{a.port}/REVIEW.html',flush=True)
ThreadingHTTPServer(('0.0.0.0' if a.lan else '127.0.0.1',a.port),SimpleHTTPRequestHandler).serve_forever()
