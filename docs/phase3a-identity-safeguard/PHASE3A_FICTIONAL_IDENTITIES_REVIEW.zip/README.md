# Fictional identity safeguard review
Extract and run python3 start_review.py; open the printed local REVIEW.html.
No Node installation or network is needed for gameplay. --lan is optional private-LAN review.
The ordinary development world has 26 unique NPCs. Six archive inhabitants are fictional, not actual historical people. Approved artwork, animation, IDs, navigation, world, players and cosmetics are unchanged. Choose a character in the original Character Studio if using fresh storage.
Use the contextual cultural archive near palace, bookshop or coast. QA-entry links only position the player at existing review approaches; they do not unlock the roster.
Native crops and actual gameplay video are local. Optional full native originals are linked to the immutable online checkpoint. Rights and provenance documents are internal review material, not the fictional characters' biographies.
Commercial depiction rights remain unverified. Renaming is not legal clearance. Historical factual biographies stay disabled. Physical Android/iPhone/hardware GPU remain NOT TESTED. Phase 3B has not started. No main merge or public deployment.
