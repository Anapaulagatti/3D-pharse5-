KOREAN ARENA — V9 REVIEW CANDIDATE (USER ART APPROVAL PENDING)

1. Extract this whole ZIP, retaining its directory structure.
2. Install/use Python3. Open a terminal inside Korean-Arena-V9-World-Review.
3. Run: python start.py (Windows can use: py start.py)
4. Open http://localhost:8765/3D-pharse5-/v9-world-review.html in a browser.

Alternative: python -m http.server 8765 from this same folder, then open the same URL.
Do not double-click index.html or use a raw source-code viewer; the bundled app needs HTTP.
No Node, API key, login, remote service or paid dependency is required for this static package.

WASD/arrows or joystick move; hold Shift/Run to run; E/Explore interacts.
Emote menu: Wave/Celebrate. Ferry: walk onto the landing, Explore, then confirm the trip.
Settings: reduced motion follows OS preference, native1x/2x zoom and Canvas compatibility.
Mobile: landscape; controls stay available and portrait orientation pauses the game.
This is a fictional learning-tour geography, not a real mainland/Jeju route reconstruction.
No public deployment or map-lock approval is implied.
