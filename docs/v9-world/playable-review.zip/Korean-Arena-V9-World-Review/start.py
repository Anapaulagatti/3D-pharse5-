#!/usr/bin/env python3
from pathlib import Path
import argparse,functools,http.server,webbrowser
p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);p.add_argument('--no-browser',action='store_true');a=p.parse_args();root=Path(__file__).resolve().parent
class Handler(http.server.SimpleHTTPRequestHandler):
 def do_GET(self):
  if self.path=='/favicon.ico':self.send_response(204);self.end_headers();return
  super().do_GET()
url=f'http://localhost:{a.port}/3D-pharse5-/v9-world-review.html'
with http.server.ThreadingHTTPServer(('127.0.0.1',a.port),functools.partial(Handler,directory=str(root)))as server:
 print('Open in a web browser:',url,flush=True)
 if not a.no_browser:webbrowser.open(url)
 try:server.serve_forever()
 except KeyboardInterrupt:pass
