# Visual review

[Open gallery](VISUAL_REVIEW.html). Native PNGs remain untouched; lightweight JPEGs are derivatives. Main-hall proposal is separate and not adopted. Physical hardware/device testing is NOT TESTED.

## palace-compound

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/palace-compound-before-native.png) · [After native](palace-compound-after-native.png)

![Before left / after right](palace-compound-comparison.jpg)

## palace-court

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/palace-court-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/palace-court-after-native.png)

![Before left / after right](palace-court-comparison.jpg)

## palace-west

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/palace-west-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/palace-west-after-native.png)

![Before left / after right](palace-west-comparison.jpg)

## palace-east

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/palace-east-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/palace-east-after-native.png)

![Before left / after right](palace-east-comparison.jpg)

## station-rear

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-rear-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-rear-after-native.png)

![Before left / after right](station-rear-comparison.jpg)

## station-left

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-left-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-left-after-native.png)

![Before left / after right](station-left-comparison.jpg)

## station-right

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-right-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-right-after-native.png)

![Before left / after right](station-right-comparison.jpg)

## modern

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/modern-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/modern-after-native.png)

![Before left / after right](modern-comparison.jpg)

## station-precinct

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-precinct-before-native.png) · [After native](station-precinct-after-native.png)

![Before left / after right](station-precinct-comparison.jpg)

## station-forecourt

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-forecourt-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-forecourt-after-native.png)

![Before left / after right](station-forecourt-comparison.jpg)

## station-amusement

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-amusement-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/station-amusement-after-native.png)

![Before left / after right](station-amusement-comparison.jpg)

## jeju-bridge

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/jeju-bridge-before-native.png) · [After native](jeju-bridge-after-native.png)

![Before left / after right](jeju-bridge-comparison.jpg)

## jeju-offshore

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/jeju-offshore-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/jeju-offshore-after-native.png)

![Before left / after right](jeju-offshore-comparison.jpg)

## jeju-south

[Before native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/jeju-south-before-native.png) · [After native](https://raw.githubusercontent.com/Anapaulagatti/3D-pharse5-/refs/tags/checkpoint/g3d-spatial-reconciliation-review-20261024/docs/gate3-reconciliation/jeju-south-after-native.png)

![Before left / after right](jeju-south-comparison.jpg)

