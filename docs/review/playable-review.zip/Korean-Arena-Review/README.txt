Korean Arena — current animation/historical guest review, NOT PUBLICLY RELEASED.
Extract, run python3 start.py (Windows py start.py), open printed HTTPURL. Python3required; noNode needed to view. Do not open index.html as source or file://. Ctrl+C stops.
WASD/arrows walk; Shift run; E nearby guest; Spacewave. Touchpad/buttons, hair/outfit/satchel/4moods/zoom, OSreducedmotion/pause/Canvasfallback. Guests are educational fictional projections from different eras. Hooks are concepts only, no fullquests/onlineusers/backend/ads.
