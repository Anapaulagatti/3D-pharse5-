from pathlib import Path
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from functools import partial
import argparse,webbrowser
p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8000);p.add_argument('--no-browser',action='store_true');p.add_argument('--canvas',action='store_true');p.add_argument('--lan',action='store_true');a=p.parse_args()
path='/3D-pharse5-/v7-world-review.html'+('?renderer=canvas'if a.canvas else '')
url=f'http://127.0.0.1:{a.port}'+path
server=ThreadingHTTPServer(('0.0.0.0'if a.lan else '127.0.0.1',a.port),partial(SimpleHTTPRequestHandler,directory=str(Path(__file__).resolve().parent)))
print('Open: '+url,flush=True)
if a.lan:print('Same-WiFi phone: http://YOUR_COMPUTER_LAN_IP:'+str(a.port)+path,flush=True)
if not a.no_browser:webbrowser.open(url)
try:server.serve_forever()
except KeyboardInterrupt:server.server_close()
