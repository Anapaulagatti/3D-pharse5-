KOREAN ARENA — V7 LIVING KOREA RECONSTRUCTION / USER VISUAL REVIEW, NOT PUBLIC RELEASE.
Extract ENTIRE Korean-Arena-V7-World-Review folder. Python3 required; no Node/account/API.
Run python3 start.py (Windows: py start.py), then open printed HTTP URL.
Never file:// or HTML source viewer. Ctrl+C stops. Optional --canvas, --lan for same-WiFi phone; manually rotate landscape.
WASD/arrows, Shift run, E Explore, Space wave; landscape joystick+Run+Explore/Talk/Emote. Portrait pauses, OS reduced-motion respected.
Follow unchanged palace/Academy north through warm threshold to station gardens/frontage, real central rail crossing/platform stair. West boulevard enters Namsan winding park; east promenade reaches centered amusement arch. Short coastal bridge crosses real inlet. Terminal→narrow boarding pier→Explore→confirm ferry to Jeju; northern island landing returns. Explore original Academy reading room/Hangul desk, basalt discovery, landmarks.
4352x5312, original native landmark images/Juni144frames preserved. New clean route/site graph, modern station/commercial plots, independent park campuses, real shore and island routes. Fictional educational geography; not historical reconstruction. Train/rides static scenic art, not minigames.
This package contains current V7 and retained base-town brand link only; older reviews, editable sources, archived3D and all recovery points remain in Git repository, not included here.
No paid API/backend/accounts/ads/multiplayer/public deployment. Actual physical phones/Safari/GPU unmeasured. STOP for user's visual approval.
